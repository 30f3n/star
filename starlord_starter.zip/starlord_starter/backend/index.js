const express = require('express');
const multer = require('multer');
const sharp = require('sharp');
const { nanoid } = require('nanoid');
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
require('dotenv').config();

const PORT = process.env.PORT || 4000;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const UPLOAD_DIR = process.env.UPLOAD_DIR || './uploads';
const LOGO_PATH = process.env.LOGO_PATH || './logo.png';
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const db = new Database(process.env.DB_PATH || './db.sqlite');
db.exec(`CREATE TABLE IF NOT EXISTS images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT UNIQUE,
  filename TEXT,
  original_name TEXT,
  mime TEXT,
  width INTEGER,
  height INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  views INTEGER DEFAULT 0,
  is_private INTEGER DEFAULT 0
)`);

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads'), { maxAge: '1y' }));
app.use(express.static(path.join(__dirname, '..', 'frontend')));

const storage = multer.memoryStorage();
const upload = multer({ storage, limits: { fileSize: 30 * 1024 * 1024 } });

app.post('/api/upload', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file' });
    const slug = nanoid(8);
    const filename = `${slug}.webp`;
    const outPath = path.join(UPLOAD_DIR, filename);

    // prepare logo if exists
    let logoBuffer = null;
    if (fs.existsSync(LOGO_PATH)) {
      try { logoBuffer = await sharp(LOGO_PATH).resize({ width: 220 }).png().toBuffer(); } catch(e) { logoBuffer = null; }
    }

    const img = sharp(req.file.buffer);
    const meta = await img.metadata();
    const maxDim = 2000;
    const width = meta.width > maxDim ? maxDim : meta.width;
    const height = meta.height > maxDim ? Math.round(meta.height * width / meta.width) : meta.height;

    let pipeline = img.resize(width, height);
    if (logoBuffer) {
      pipeline = pipeline.composite([{ input: logoBuffer, gravity: 'southeast', blend: 'over' }]);
    }
    await pipeline.webp({ quality: 85 }).toFile(outPath);

    db.prepare('INSERT INTO images (slug, filename, original_name, mime, width, height) VALUES (?,?,?,?,?,?)')
      .run(slug, filename, req.file.originalname || '', 'image/webp', width, height);

    res.json({ success: true, url: `${BASE_URL}/s/${slug}`, slug });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'processing_error', details: err.message });
  }
});

app.get('/s/:slug', (req, res) => {
  const slug = req.params.slug;
  const row = db.prepare('SELECT * FROM images WHERE slug = ?').get(slug);
  if (!row) return res.status(404).send('Not found');
  db.prepare('UPDATE images SET views = views + 1 WHERE id = ?').run(row.id);
  const filePath = path.join(UPLOAD_DIR, row.filename);
  res.set('Cache-Control', 'public, max-age=31536000');
  res.sendFile(path.resolve(filePath));
});

app.get('/api/info/:slug', (req, res) => {
  const slug = req.params.slug;
  const row = db.prepare('SELECT slug, original_name, created_at, views, is_private FROM images WHERE slug = ?').get(slug);
  if (!row) return res.status(404).json({ error: 'notfound' });
  res.json(row);
});

app.listen(PORT, () => console.log(`Server listening on ${PORT}`));
